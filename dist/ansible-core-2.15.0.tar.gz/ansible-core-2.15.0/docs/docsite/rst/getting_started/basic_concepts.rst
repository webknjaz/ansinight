.. _basic_concepts:

****************
Ansible concepts
****************

These concepts are common to all uses of Ansible.
You should understand them before using Ansible or reading the documentation.

.. contents::
   :local:

.. include:: /shared_snippets/basic_concepts.txt
